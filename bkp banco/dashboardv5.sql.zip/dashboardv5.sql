-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 24/03/2025 às 20:53
-- Versão do servidor: 10.6.7-MariaDB
-- Versão do PHP: 8.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dashboardv5`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `clients`
--

INSERT INTO `clients` (`id`, `xid`, `name`, `created_at`, `updated_at`) VALUES
(1, 'CL_A1B2C3', 'AEROPORTO DE BRASILIA INFRAMERICA', '2025-03-24 20:15:34', '2025-03-24 20:15:35'),
(2, 'CL_D4E518', 'ALLERGAN PRODUTOS FARMACEUTICOS', '2025-03-24 20:15:36', '2025-03-24 20:15:37'),
(3, 'CL_G7H8I9', 'AMERICA', '2025-03-24 20:15:37', '2025-03-24 20:15:38'),
(4, 'CL_MN8O1P', 'ANHEMBI MORUMBI', '2025-03-24 20:15:38', '2025-03-24 20:15:39'),
(5, 'CL_QR9S0T', 'ARCOR BRAGANCA', '2025-03-24 20:15:39', '2025-03-24 20:15:40'),
(6, 'CL_UV1W2X', 'ARCOR RIO DAS PEDRAS', '2025-03-24 20:15:41', '2025-03-24 20:15:41'),
(7, 'CL_YZ3A4B', 'ATC ALPHAVILLE TENIS CLUBE', '2025-03-24 20:15:42', '2025-03-24 20:15:43'),
(8, 'CL_C5D6E7', 'BRASCAN CENTURY', '2025-03-24 20:15:43', '2025-03-24 20:15:44'),
(9, 'CL_F8G9H0', 'BRAZILIAN FINANCIAL CENTER', '2025-03-24 20:15:46', '2025-03-24 20:15:46'),
(10, 'CL_I1J2K3', 'CATALENT', '2025-03-24 20:15:47', '2025-03-24 20:15:48'),
(11, 'CL_L4M5N6', 'CATARINA FASHION OUTLET', '2025-03-24 20:15:49', '2025-03-24 20:15:49'),
(12, 'CL_O7P8Q9', 'CBOP CASTELLO BRANCO OFFICE PARK', '2025-03-24 20:15:50', '2025-03-24 20:15:51'),
(13, 'CL_R0S1T2', 'CENTRO EMPRESARIAL DO ACO', '2025-03-24 20:15:51', '2025-03-24 20:15:52'),
(14, 'CL_U3V4W5', 'CENU', '2025-03-24 20:15:52', '2025-03-24 20:15:53'),
(15, 'CL_X6Y7Z8', 'CETENCO', '2025-03-24 20:15:54', '2025-03-24 20:15:55'),
(16, 'CL_A9B0C1', 'CITIBANK', '2025-03-24 20:15:55', '2025-03-24 20:15:56'),
(17, 'CL_D2E3F4', 'CLUBE HIPICO DE SANTO AMARO', '2025-03-24 20:15:57', '2025-03-24 20:15:57'),
(18, 'CL_G5H6I7', 'CLUBE IPE', '2025-03-24 20:15:58', '2025-03-24 20:15:59'),
(19, 'CL_J8K9L0', 'CLUBE PAINEIRAS', '2025-03-24 20:16:00', '2025-03-24 20:16:01'),
(20, 'CL_M1N2O3', 'CLUBE PINHEIROS', '2025-03-24 20:16:01', '2025-03-24 20:16:02'),
(21, 'CL_P4Q5R6', 'CONDOMINIO COMPLEXO MADEIRA', '2025-03-24 20:16:03', '2025-03-24 20:16:04'),
(22, 'CL_S7T8U9', 'CONDOMINIO E TOWER', '2025-03-24 20:16:04', '2025-03-24 20:16:05'),
(23, 'CL_V0W1X2', 'CONDOMINIO EDIFICIO ELUMA', '2025-03-24 20:16:07', '2025-03-24 20:16:06'),
(24, 'CL_Y3Z4A5', 'CONDOMINIO SAO LUIZ', '2025-03-24 20:16:09', '2025-03-24 20:16:06'),
(25, 'CL_B6C7D8', 'CONDOMINIO TOP CENTER', '2025-03-24 20:16:09', '2025-03-24 20:16:16'),
(26, 'CL_E9F0G1', 'CONDOMINIO VILLA LOBOS', '2025-03-24 20:16:10', '2025-03-24 20:16:16'),
(27, 'CL_H2I3J4', 'CONDOMINIO VILLA LOBOS OFFICE PARK', '2025-03-24 20:16:10', '2025-03-24 20:16:17'),
(28, 'CL_K5L6M7', 'CRYOVAC BRASIL', '2025-03-24 20:16:11', '2025-03-24 20:16:17'),
(29, 'CL_N8O9P0', 'DAN VIGOR INDUSTRIA E COMERCIO DE LATICINIOS', '2025-03-24 20:16:11', '2025-03-24 20:16:18'),
(30, 'CL_Q1R2S3', 'EDIFICIO EVOLUTION CORPORATE', '2025-03-24 20:16:31', '2025-03-24 20:16:24'),
(31, 'CL_T4U5V6', 'ESTANPLAZA FUNCHAL', '2025-03-24 20:16:12', '2025-03-24 20:16:22'),
(32, 'CL_W7X8Y9', 'EUROFARMA', '2025-03-24 20:16:14', '2025-03-24 20:16:26'),
(33, 'CL_Z0A1B2', 'FARIA LIMA FINANCIAL CENTER', '2025-03-24 20:16:14', '2025-03-24 20:16:34'),
(34, 'CL_C3D4E5', 'FARIA LIMA TOWER', '2025-03-24 20:16:13', '2025-03-24 20:16:35'),
(35, 'CL_F6G7H8', 'FRESENIUS MEDICAL CARE', '2025-03-24 20:16:36', '2025-03-24 20:16:37'),
(36, 'CL_I9J0K1', 'FUNDACAO CASPER LIBERO', '2025-03-24 20:16:40', '2025-03-24 20:16:39'),
(37, 'CL_L2M3N4', 'GOLDEN SQUARE SHOP. S. BERNARDO', '2025-03-24 20:16:41', '2025-03-24 20:16:43'),
(38, 'CL_O5P6Q7', 'GRAND PLAZA SHOPPING', '2025-03-24 20:16:44', '2025-03-24 20:16:44'),
(39, 'CL_R8S9T0', 'GRU AEROPORTO INTERNACIONAL DE SAO PAULO', '2025-03-24 20:16:49', '2025-03-24 20:16:49'),
(40, 'CL_U1V2W3', 'HOSPITAL ALEMÃO OSWALDO CRUZ', '2025-03-24 20:16:50', '2025-03-24 20:16:50'),
(41, 'CL_X4Y5Z6', 'HOSPITAL CARLOS CHAGAS', '2025-03-24 20:16:51', '2025-03-24 20:16:51'),
(42, 'CL_A7B8C9', 'HOSPITAL DA BAHIA', '2025-03-24 20:16:53', '2025-03-24 20:16:52'),
(43, 'CL_D0E1F2', 'HOSPITAL PAULISTANO', '2025-03-24 20:16:53', '2025-03-24 20:17:46'),
(44, 'CL_G3H4I5', 'HOSPITAL SAMARITANO', '2025-03-24 20:16:54', '2025-03-24 20:17:46'),
(45, 'CL_J6K7L8', 'HOSPITAL SANTA HELENA  SAO BERNARDO', '2025-02-24 20:16:54', '2025-03-24 20:17:46'),
(46, 'CL_M9N0O1', 'HOSPITAL SANTA IZABEL', '2025-03-24 20:16:56', '2025-03-24 20:17:47'),
(47, 'CL_P2Q3R4', 'HOSPITAL SAO CAMILO IPIRANGA', '2025-02-24 20:16:56', '2025-03-24 20:17:47'),
(48, 'CL_S5T6U7', 'HOSPITAL SAO CAMILO POMPEIA', '2025-03-24 20:17:00', '2025-03-24 20:17:47'),
(49, 'CL_V8W9X0', 'HOSPITAL SAO CAMILO SANTANA', '2025-03-24 20:17:00', '2025-03-24 20:17:48'),
(50, 'CL_Y1Z2A3', 'HOSPITAL VITORIA', '2025-03-24 20:17:04', '2025-03-24 20:17:48'),
(51, 'CL_B4C5D6', 'INDUSTRIAS ANHEMBI S/A', '2025-04-24 20:17:01', '2025-03-24 20:17:48'),
(52, 'CL_E7F8G9', 'INFINITY TOWER', '2025-03-24 20:17:06', '2025-03-24 20:17:49'),
(53, 'CL_H0I1J2', 'ITAU UNIBANCO CEIC', '2025-03-24 20:17:09', '2025-03-24 20:17:49'),
(54, 'CL_K3L4M5', 'ITAU UNIBANCO EUDORO', '2025-03-24 20:17:10', '2025-03-24 20:17:49'),
(55, 'CL_N6O7P8', 'ITM CENTRO TEXTIL', '2025-03-24 20:17:10', '2025-03-24 20:17:50'),
(56, 'CL_Q9R0S1', 'JUNDIAI SHOPPING', '2025-03-24 20:17:11', '2025-03-24 20:17:50'),
(57, 'CL_T2U3V4', 'LIOTECNICA', '2025-03-24 20:17:11', '2025-03-24 20:17:50'),
(58, 'CL_W5X6Y7', 'LITORAL PLAZA SHOPPING', '2025-03-24 20:17:11', '2025-03-24 20:17:51'),
(59, 'CL_Z8A9B0', 'LUXOTTICA CAMPINAS', '2025-03-24 20:17:12', '2025-03-24 20:17:51'),
(60, 'CL_C1D2E3', 'LUXOTTICA SUMARE', '2025-03-24 20:17:12', '2025-03-24 20:17:52'),
(61, 'CL_F4G5H6', 'MACKENZIE', '2025-03-24 20:17:12', '2025-03-24 20:17:52'),
(62, 'CL_I7J8K9', 'MOOCA PLAZA SHOPPING', '2025-03-24 20:17:13', '2025-03-24 20:17:52'),
(63, 'CL_L0M1N2', 'MORUMBI TOWER', '2025-03-24 20:17:13', '2025-03-24 20:17:53'),
(64, 'CL_O3P4Q5', 'OFFICE TAMBORE', '2025-03-24 20:17:13', '2025-03-24 20:17:53'),
(65, 'CL_R6S7T8', 'PATIO VICTOR MALZONI', '2025-03-24 20:17:14', '2025-03-24 20:17:53'),
(66, 'CL_U9V0W1', 'PIRELLI AGUA INDUSTRIAL', '2025-03-24 20:17:14', '2025-03-24 20:17:54'),
(67, 'CL_X2Y3Z4', 'PIRELLI AGUA POTAVEL', '2025-03-24 20:17:14', '2025-03-24 20:17:54'),
(68, 'CL_A5B6C7', 'PKS PARK SHOPPING', '2025-03-24 20:17:15', '2025-03-24 20:17:54'),
(69, 'CL_D8E9F0', 'PLAZA SHOPPING NITEROI', '2025-03-24 20:17:15', '2025-03-24 20:17:55'),
(70, 'CL_G1H2I3', 'POLO SHOPPING', '2025-03-24 20:17:15', '2025-03-24 20:17:55'),
(71, 'CL_J4K5L6', 'PORTO SEGURO', '2025-03-24 20:17:16', '2025-03-24 20:17:55'),
(72, 'CL_M7N8O9', 'PROLOGIS', '2025-03-24 20:17:16', '2025-03-24 20:17:56'),
(73, 'CL_P0Q1R2', 'QUARTEIRAO SAO LUIZ', '2025-03-24 20:17:16', '2025-03-24 20:17:56'),
(74, 'CL_S3T4U5', 'ROQUETTE', '2025-03-24 20:17:17', '2025-03-24 20:17:56'),
(75, 'CL_V6W7X8', 'ROYAL PALM HALL', '2025-03-24 20:17:17', '2025-03-24 20:17:57'),
(76, 'CL_Y9Z0A1', 'ROYAL PALM PLAZA', '2025-03-24 20:17:17', '2025-03-24 20:17:57'),
(77, 'CL_B2C3D4', 'SALVADOR SHOPPING', '2025-03-24 20:17:18', '2025-03-24 20:17:57'),
(78, 'CL_E5F6G7', 'SAO BERNARDO PLAZA SHOPPING', '2025-03-24 20:17:18', '2025-03-24 20:17:58'),
(79, 'CL_H8I9J0', 'SAO JUDAS', '2025-03-24 20:17:18', '2025-03-24 20:17:58'),
(80, 'CL_K1L2M3', 'SEKURIT', '2025-03-24 20:17:19', '2025-03-24 20:17:58'),
(81, 'CL_N4O5P6', 'SHOPPING ABC', '2025-03-24 20:17:19', '2025-03-24 20:17:59'),
(82, 'CL_Q7R8S9', 'SHOPPING ANALIA FRANCO', '2025-03-24 20:17:19', '2025-03-24 20:17:59'),
(83, 'CL_T0U1V2', 'SHOPPING CANTAREIRA', '2025-03-24 20:17:20', '2025-03-24 20:17:59'),
(84, 'CL_W3X4Y5', 'SHOPPING CENTER NORTE', '2025-03-24 20:17:20', '2025-03-24 20:18:00'),
(85, 'CL_Z6A7B8', 'SHOPPING CIDADE', '2025-03-24 20:17:20', '2025-03-24 20:18:00'),
(86, 'CL_C9D0E1', 'SHOPPING CONTINENTAL', '2025-03-24 20:17:21', '2025-03-24 20:18:00'),
(87, 'CL_F2G3H4', 'SHOPPING D', '2025-03-24 20:17:21', '2025-03-24 20:18:01'),
(88, 'CL_I5J6K7', 'SHOPPING ELDORADO', '2025-03-24 20:17:21', '2025-03-24 20:18:01'),
(89, 'CL_L8M9N0', 'SHOPPING FREI CANECA', '2025-03-24 20:17:21', '2025-03-24 20:18:02'),
(90, 'CL_O1P2Q3', 'SHOPPING GALERIA', '2025-03-24 20:17:22', '2025-03-24 20:18:02'),
(91, 'CL_R4S5T6', 'SHOPPING GRANJA VIANA', '2025-03-24 20:17:22', '2025-03-24 20:18:02'),
(92, 'CL_U7V8W9', 'SHOPPING IGUATEMI CAMPINAS', '2024-11-24 20:17:23', '2025-03-24 20:18:03'),
(93, 'CL_X0Y1Z2', 'SHOPPING IGUATEMI RIBEIRAO', '2025-03-24 20:17:27', '2025-03-24 20:18:03'),
(94, 'CL_A3B4C5', 'SHOPPING IGUATEMI SAO JOSE DO RIO PRETO', '2025-03-24 20:17:28', '2025-03-24 20:18:03'),
(95, 'CL_D6E7F8', 'SHOPPING IGUATEMI SAO PAULOA', '2025-03-24 20:17:28', '2025-03-24 20:18:04'),
(96, 'CL_G9H0I1', 'SHOPPING IGUATEMI SP', '2025-03-24 20:17:28', '2025-03-24 20:18:04'),
(97, 'CL_J2K3L4', 'SHOPPING ITAQUERA', '2025-03-24 20:17:29', '2025-03-24 20:18:04'),
(98, 'CL_M5N6O7', 'SHOPPING JARDIM SUL', '2025-03-24 20:17:29', '2025-03-24 20:18:05'),
(99, 'CL_P8Q9R0', 'SHOPPING JK IGUATEMI', '2025-03-24 20:17:29', '2025-03-24 20:18:05'),
(100, 'CL_S1T2U3', 'SHOPPING MAIS', '2025-03-24 20:17:30', '2025-03-24 20:18:05'),
(101, 'CL_V4W5X6', 'SHOPPING PARQUE DAS  BANDEIRAS', '2025-03-24 20:17:30', '2025-03-24 20:18:06'),
(102, 'CL_Y7Z8A9', 'SHOPPING PARQUE DOM PEDRO', '2025-03-24 20:17:30', '2025-03-24 20:18:06'),
(103, 'CL_B0C1D2', 'SHOPPING PENHA', '2025-03-24 20:17:31', '2025-03-24 20:18:06'),
(104, 'CL_E3F4G5', 'SHOPPING PLAZA SUL', '2025-03-24 20:17:31', '2025-03-24 20:18:07'),
(105, 'CL_H6I7J8', 'SHOPPING PRACA DA MOCA', '2025-03-24 20:17:31', '2025-03-24 20:18:07'),
(106, 'CL_K9L0M1', 'SHOPPING SHOPPING ANALIA FRANCO', '2025-03-24 20:17:32', '2025-03-24 20:18:08'),
(107, 'CL_N2O3P4', 'SHOPPING SHOPPING CIDADE', '2025-03-24 20:17:32', '2025-03-24 20:18:08'),
(108, 'CL_Q5R6S7', 'SHOPPING SHOPPING IGUATEMI ALPHAVILLE', '2025-03-24 20:17:32', '2025-03-24 20:18:08'),
(109, 'CL_T8U9V0', 'SHOPPING SHOPPING ITAQUERA', '2025-03-24 20:17:33', '2025-03-24 20:18:09'),
(110, 'CL_W1X2Y3', 'SHOPPING SHOPPING JK IGUATEMI', '2025-03-24 20:17:33', '2025-03-24 20:18:09'),
(111, 'CL_Z4A5B6', 'SHOPPING SHOPPING PIRACICABA', '2025-03-24 20:17:33', '2025-03-24 20:18:09'),
(112, 'CL_C7D8E9', 'SHOPPING SHOPPING PLAZA SUL', '2025-03-24 20:17:34', '2025-03-24 20:18:10'),
(113, 'CL_F0G1H2', 'SHOPPING SHOPPING PRACA DA MOCA', '2025-03-24 20:17:34', '2025-01-24 20:18:10'),
(114, 'CL_I3J4K5', 'SHOPPING SHOPPING VILLA LOBOS', '2025-03-24 20:17:35', '2025-03-24 20:18:15'),
(115, 'CL_L6M7N8', 'SHOPPING TAMBORE', '2025-03-24 20:17:35', '2025-03-24 20:18:15'),
(116, 'CL_O9P0Q1', 'SHOPPING TIETE PLAZA SHOPPING', '2025-03-24 20:17:35', '2025-03-24 20:18:15'),
(117, 'CL_R2S3T4', 'SHOPPING VILLA LOBOS', '2025-03-24 20:17:36', '2025-03-24 20:18:16'),
(118, 'CL_U5V6W7', 'TOTAL QUIMICA', '2025-03-24 20:17:36', '2025-03-24 20:18:16'),
(119, 'CL_X8Y9Z0', 'UNIAO QUIMICA  INOVAT', '2025-03-24 20:17:36', '2025-03-24 20:18:17'),
(120, 'CL_A1B2C2', 'WHEATON', '2025-03-24 20:17:37', '2025-03-24 20:18:17'),
(121, 'CL_D4E5F6', 'WTC CONDOMINIO WORLD TRADE CENTER', '2025-03-24 20:17:37', '2025-03-24 20:18:18'),
(122, 'CL_G7H839', 'WTNU CONDOMINIO WTORRE NACOES UNIDAS', '2025-03-24 20:17:38', '2025-03-24 20:18:20'),
(123, 'CL_KCZBII', 'GENERAL WATER', '2025-03-24 20:19:06', '2025-03-24 20:19:06');

-- --------------------------------------------------------

--
-- Estrutura para tabela `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sector_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `files`
--

INSERT INTO `files` (`id`, `xid`, `user_xid`, `client_xid`, `system_xid`, `type_xid`, `sector_xid`, `path`, `file`, `created_at`, `updated_at`) VALUES
(2, 'FL_TU5LOO', 'US_UEZSOQ', 'CL_U5V6W7', 'SY_SYEJSH', 'TP_I8JYSI', 'SC_BFDEPA', 'C:\\HOMOLOGACAO\\ARQUIVOS\\GENERAL-WATER\\EPAR\\CCO\\', 'GENERAL-WATER-EPAR-CCO-240325-171946.pdf', '2025-03-24 20:19:46', '2025-03-24 20:19:46');

-- --------------------------------------------------------

--
-- Estrutura para tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2025_03_20_214737_sectors', 1),
(3, '2025_03_23_162535_create_profiles_table', 3),
(4, '2014_10_12_000000_create_users_table', 4),
(5, '2019_08_19_000000_create_failed_jobs_table', 4),
(6, '2019_12_14_000001_create_personal_access_tokens_table', 4),
(10, '2025_03_23_202003_create_test_data_table', 4),
(11, '2023_06_26_005931_create_clients_table', 5),
(12, '2023_06_26_011953_create_systems_table', 5),
(13, '2025_03_20_175953_types', 6),
(14, '2023_06_26_012057_create_files_table', 7);

-- --------------------------------------------------------

--
-- Estrutura para tabela `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `profiles`
--

INSERT INTO `profiles` (`id`, `xid`, `name`, `created_at`, `updated_at`) VALUES
(5, 'PF_1JLXDG', 'ADMINISTRADOR', '2025-03-24 14:09:39', '2025-03-24 14:09:39'),
(7, 'PF_Q5SSWL', 'USUÁRIO', '2025-03-24 16:30:00', '2025-03-24 16:30:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `sectors`
--

CREATE TABLE `sectors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `sectors`
--

INSERT INTO `sectors` (`id`, `xid`, `name`, `created_at`, `updated_at`) VALUES
(3, 'SC_PVWKRY', 'IMPLANTAÇÃO', '2025-03-24 14:04:53', '2025-03-24 14:04:53'),
(4, 'SC_BFDEPA', 'CCO', '2025-03-24 14:17:08', '2025-03-24 14:17:08'),
(5, 'SC_XYIYFC', 'OPERAÇÃO', '2025-03-24 14:17:21', '2025-03-24 14:17:21'),
(6, 'SC_10BCHV', 'TESTE', '2025-03-24 16:28:37', '2025-03-24 16:28:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `systems`
--

CREATE TABLE `systems` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `systems`
--

INSERT INTO `systems` (`id`, `xid`, `name`, `created_at`, `updated_at`) VALUES
(1, 'SY_V36AES', 'NA', '2025-03-24 16:57:53', '2025-03-24 16:57:53'),
(2, 'SY_SYEJSH', 'ETA', '2025-03-24 16:58:08', '2025-03-24 16:58:52'),
(3, 'SY_WTRK8X', 'EPAR', '2025-03-24 16:58:21', '2025-03-24 16:58:45'),
(4, 'SY_IUH0XA', 'CAPTAÇÃO', '2025-03-24 16:59:32', '2025-03-24 16:59:32'),
(5, 'SY_H19YSF', 'RESERVATÓRIO', '2025-03-24 16:59:48', '2025-03-24 16:59:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `test_data`
--

CREATE TABLE `test_data` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temp` double(8,2) NOT NULL,
  `hum` double(8,2) NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `types`
--

INSERT INTO `types` (`id`, `xid`, `name`, `created_at`, `updated_at`) VALUES
(1, 'TP_SBTJXF', 'SETPOINTS', '2025-03-24 17:20:41', '2025-03-24 17:20:41'),
(2, 'TP_EBGROE', 'SCADA', '2025-03-24 17:20:47', '2025-03-24 17:20:47'),
(3, 'TP_RTPNDC', 'NODERED', '2025-03-24 17:20:52', '2025-03-24 17:20:52'),
(4, 'TP_S4SA7G', 'CLP', '2025-03-24 17:20:58', '2025-03-24 17:20:58'),
(5, 'TP_Q07MDX', 'IHM', '2025-03-24 17:21:02', '2025-03-24 17:21:02'),
(6, 'TP_I8JYSI', 'ARQUIVO DE APOIO', '2025-03-24 17:21:30', '2025-03-24 17:21:30'),
(7, 'TP_THKD7H', 'DADO DE PRODUÇÃO', '2025-03-24 17:21:41', '2025-03-24 17:21:41');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `xid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sector_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_xid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_lte_dark_mode` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `xid`, `name`, `email`, `password`, `sector_xid`, `profile_xid`, `admin_lte_dark_mode`, `created_at`, `updated_at`) VALUES
(2, 'US_MXKCLH', 'USER', 'user@user.com.br', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SC_XYIYFC', 'PF_1JLXDG', 1, '2025-03-24 14:01:47', '2025-03-24 18:13:43'),
(3, 'US_UEZSOQ', 'CARLOS FERREIRA', 'carlos.ferreira@generalwater.com.br', '$2y$10$RFYVTQ17eIncmOiYd5JKQO6s0yKThOMl9QTPjePfCee.v7DYGmVXO', 'SC_BFDEPA', 'PF_1JLXDG', 1, '2025-03-24 14:16:48', '2025-03-24 19:42:01');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_xid_unique` (`xid`);

--
-- Índices de tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Índices de tabela `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `files_xid_unique` (`xid`),
  ADD KEY `files_user_xid_foreign` (`user_xid`),
  ADD KEY `files_client_xid_foreign` (`client_xid`),
  ADD KEY `files_system_xid_foreign` (`system_xid`),
  ADD KEY `files_type_xid_foreign` (`type_xid`),
  ADD KEY `files_sector_xid_foreign` (`sector_xid`);

--
-- Índices de tabela `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Índices de tabela `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `profiles_xid_unique` (`xid`);

--
-- Índices de tabela `sectors`
--
ALTER TABLE `sectors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sectors_xid_unique` (`xid`);

--
-- Índices de tabela `systems`
--
ALTER TABLE `systems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `systems_xid_unique` (`xid`);

--
-- Índices de tabela `test_data`
--
ALTER TABLE `test_data`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `types_xid_unique` (`xid`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_xid_unique` (`xid`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_sector_xid_foreign` (`sector_xid`),
  ADD KEY `users_profile_xid_foreign` (`profile_xid`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT de tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `sectors`
--
ALTER TABLE `sectors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `systems`
--
ALTER TABLE `systems`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `test_data`
--
ALTER TABLE `test_data`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_client_xid_foreign` FOREIGN KEY (`client_xid`) REFERENCES `clients` (`xid`) ON DELETE SET NULL,
  ADD CONSTRAINT `files_sector_xid_foreign` FOREIGN KEY (`sector_xid`) REFERENCES `sectors` (`xid`) ON DELETE SET NULL,
  ADD CONSTRAINT `files_system_xid_foreign` FOREIGN KEY (`system_xid`) REFERENCES `systems` (`xid`) ON DELETE SET NULL,
  ADD CONSTRAINT `files_type_xid_foreign` FOREIGN KEY (`type_xid`) REFERENCES `types` (`xid`) ON DELETE SET NULL,
  ADD CONSTRAINT `files_user_xid_foreign` FOREIGN KEY (`user_xid`) REFERENCES `users` (`xid`) ON DELETE SET NULL;

--
-- Restrições para tabelas `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_profile_xid_foreign` FOREIGN KEY (`profile_xid`) REFERENCES `profiles` (`xid`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_sector_xid_foreign` FOREIGN KEY (`sector_xid`) REFERENCES `sectors` (`xid`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
